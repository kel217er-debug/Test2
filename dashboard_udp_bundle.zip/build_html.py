#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Собирает daily_dashboard.html со встроенным JSON и встроенным Chart.js.
Рядом со скриптом должен лежать chart.umd.js (автономная копия Chart.js).
Так дашборд работает полностью offline — ни одного внешнего запроса.
"""
import json, os, sys, datetime

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE, 'daily_data.json')
TEMPLATE_PATH = os.path.join(BASE, 'dashboard_template.html')
CHARTJS_PATH = os.path.join(BASE, 'chart.umd.js')
OUT_PATH = os.path.join(BASE, 'daily_dashboard.html')

with open(DATA_PATH, 'r', encoding='utf-8') as f:
    data_raw = f.read()

with open(TEMPLATE_PATH, 'r', encoding='utf-8') as f:
    tpl = f.read()

if os.path.exists(CHARTJS_PATH):
    with open(CHARTJS_PATH, 'r', encoding='utf-8') as f:
        chartjs_raw = f.read()
    # Безопасная встройка — предотвращаем закрытие внешнего <script>
    chartjs_safe = chartjs_raw.replace('</script>', '<\\/script>')
else:
    print(f"[HTML] WARN: {CHARTJS_PATH} не найден — Chart.js не встроен. "
          f"Графики будут пустыми без интернета.")
    chartjs_safe = '/* chart.umd.js not found */'

# Безопасная встройка JSON (без экранирования </script>)
data_json = data_raw.replace('</', '<\\/')
out = tpl.replace('/*__DATA__*/', data_json)
out = out.replace('/*__CHARTJS__*/', chartjs_safe)
out = out.replace('/*__BUILD_TIME__*/', datetime.datetime.now().strftime('%Y-%m-%d %H:%M'))

with open(OUT_PATH, 'w', encoding='utf-8') as f:
    f.write(out)

print(f"[HTML] Built {OUT_PATH}, size={os.path.getsize(OUT_PATH):,} bytes")
