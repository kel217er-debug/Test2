#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ETL v2 для ежедневного дашборда тимлидов.

Ключевые изменения v2:
- Две независимые агрегации:
  * REGISTERED (по дате регистрации) — leading metrics:
    заявки, SLA, передачи, нагрузка, открытые/застрявшие
  * CLOSED (по дате перевода в итоговый статус, col 127) — lagging metrics:
    подключения, НД, услуги, оборудование
- Периоды:
  * Закрытые месяцы — один тотал на месяц
  * Текущий (открытый) месяц — понедельная разбивка
- Cohort-матрица (close_month × reg_month) — видно, из каких недель
  регистрации закрываются заявки в данном периоде
"""

import os, sys, re, json, time
from datetime import datetime, timedelta
from collections import defaultdict, Counter

# -------- конфиг --------
OUR_CHANNELS = {'НОД', 'Партнеры НОД', 'НПГС'}
DIR_MAP = {'НОД': 'НИР', 'Партнеры НОД': 'НПП', 'НПГС': 'НСП'}
EXCL_SERVICES = {'другие услуги', 'другая услуга', 'заказ оборудования'}
CONNECTED_STATUS = 'Клиент подключен'
STALE_HOURS = 720  # 30 дней

COL = {
    'mrf': 0,
    'region': 1,
    'reg_dt': 10,
    'channel': 12,
    'service': 19,
    'equip_price': 24,
    'inn': 31,
    'segment': 33,
    'exec_name': 50,
    'exec_podr': 51,
    'accept_dt': 52,
    'primary_name': 53,
    'primary_podr': 54,
    'sla_cont': 66,
    'sla_acc': 67,
    'transfer_dt': 70,
    'connection_result': 120,
    'connector_name': 121,
    'connected_services_cnt': 124,
    'install_amount': 125,
    'monthly_amount': 126,
    'final_dt': 127,          # Дата перевода в итоговый статус (close date)
    'final_status': 128,
    'final_reason': 129,
    'current_status': 133,
    'current_exec': 134,
    'current_podr': 135,
    'hrs_since_reg': 136,
    'hrs_in_status': 137,
}

# -------- helpers --------
_DT_RE = re.compile(r'^\s*(\d{1,2})\.(\d{1,2})\.(\d{4})\s+(\d{1,2}):(\d{1,2}):(\d{1,2})\s*$')

def parse_dt(v):
    if v is None: return None
    if isinstance(v, datetime): return v
    if isinstance(v, str):
        s = v.strip()
        if not s: return None
        m = _DT_RE.match(s)
        if m:
            d, mo, y, H, M, S = map(int, m.groups())
            try: return datetime(y, mo, d, H, M, S)
            except ValueError: return None
    return None

def parse_num(v):
    if v is None: return 0.0
    if isinstance(v, (int, float)): return float(v)
    s = str(v).strip().replace('\xa0','').replace(' ','').replace(',','.')
    if not s: return 0.0
    try: return float(s)
    except: return 0.0

def norm_str(v):
    return '' if v is None else str(v).strip()

def clean_name(v):
    s = norm_str(v)
    if not s: return ''
    if '@' in s:
        parts = s.split()
        clean = []
        for p in parts:
            if '@' in p: break
            clean.append(p)
        s = ' '.join(clean)
    return s.strip()

def iso_week_key(dt):
    y, w, _ = dt.isocalendar()
    monday = dt - timedelta(days=dt.isoweekday() - 1)
    monday = datetime(monday.year, monday.month, monday.day)
    sunday = monday + timedelta(days=6, hours=23, minutes=59, seconds=59)
    return f"{y}-W{w:02d}", monday, sunday

def month_key(dt):
    return f"{dt.year}-{dt.month:02d}"

def month_label(mkey):
    y, m = map(int, mkey.split('-'))
    names = ['', 'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
             'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь']
    return names[m] if 1 <= m <= 12 else mkey

def month_bounds(mkey):
    y, m = map(int, mkey.split('-'))
    start = datetime(y, m, 1)
    if m == 12: end = datetime(y+1, 1, 1) - timedelta(seconds=1)
    else: end = datetime(y, m+1, 1) - timedelta(seconds=1)
    return start, end

# -------- иерархия --------

def load_hierarchy(html_path):
    with open(html_path, 'r', encoding='utf-8') as f:
        html = f.read()
    m = re.search(r'const\s+EXTRA\s*=\s*', html)
    if not m: return None
    start = m.end()
    depth = 0; in_str=False; str_ch=None; escape=False; end=None
    for i in range(start, len(html)):
        ch = html[i]
        if escape: escape=False; continue
        if in_str:
            if ch=='\\': escape=True
            elif ch==str_ch: in_str=False
        else:
            if ch in '"\'':
                in_str=True; str_ch=ch
            elif ch=='{': depth+=1
            elif ch=='}':
                depth-=1
                if depth==0: end=i+1; break
    extra = json.loads(html[start:end])
    employees = extra.get('employees', {})
    emp_map = {}
    for name, info in employees.items():
        emp_map[name.strip()] = {
            'teamlead': info.get('teamlead') or '',
            'director': info.get('director') or '',
            'direction': info.get('direction') or '',
            'mrf': info.get('mrf') or '',
            'is_active': info.get('is_active', True),
        }
    for h in extra.get('hierarchy', []):
        name = (h.get('manager') or '').strip()
        if name and name not in emp_map:
            emp_map[name] = {
                'teamlead': h.get('teamlead') or '',
                'director': h.get('director') or '',
                'direction': h.get('direction') or '',
                'mrf': h.get('mrf') or '',
                'is_active': h.get('is_active', True),
            }
    return emp_map

# -------- агрегаты --------

def new_reg_metrics():
    """Leading метрики (агрегация по дате регистрации)."""
    return {
        'n_total': 0, 'n_base_all': 0, 'n_stayed_base': 0,
        'n_transferred': 0, 'n_sla_acc_viol': 0, 'n_sla_cont_viol': 0,
        # "Результаты, полученные по регистрации этого периода" — тоже учитываем,
        # чтобы показать cohort-конверсию "с этой когорты в итоге закрылось":
        'n_connected_stayed_from_period': 0,
        'nd_sum_from_period': 0.0,
    }

def new_closed_metrics():
    """Lagging метрики (агрегация по дате закрытия)."""
    return {
        'n_closed': 0,           # всех закрытых в периоде (любой итоговый статус)
        'n_connected': 0,        # из них подключенных
        'n_with_equip': 0,       # подключений с оборудованием
        'nd_sum': 0.0,
        'by_service': defaultdict(int),
        'by_service_equip': defaultdict(int),
        # Cross-sell + фрод-индикатор (только среди подключённых, без EXCL_SERVICES)
        'inn_services': defaultdict(set),   # ИНН -> set(услуг)
        'secondaries': [],                  # список (service, monthly_amount) для не-Интернет продуктов
    }

# Пороговое значение «ультра-дешёвого» 2-го продукта (₽/мес).
# Ниже этой суммы — сильный индикатор накрутки KPI (Мобильное ТВ ~366, ИТВ ~366-610, Корп.почта ~146).
ULTRA_CHEAP_RUB = 400.0
INET_LOWER = 'интернет'

def new_open_rec():
    return {'n_open': 0, 'n_stale30': 0, 'by_week': Counter(), 'stale_by_week': Counter()}

# -------- основной проход --------

def run_etl(muz_path, html_path, out_path):
    t0 = time.time()
    print(f"[ETL v2] Start. muz={muz_path}")

    emp_map = load_hierarchy(html_path)
    print(f"[ETL v2] Hierarchy: {len(emp_map)} employees")

    # Calamine
    from python_calamine import CalamineWorkbook
    wb = CalamineWorkbook.from_path(muz_path)
    sheet = wb.get_sheet_by_name('Sheet1')
    rows_iter = iter(sheet.to_python())
    _header = next(rows_iter)

    # --- структуры ---
    # Для каждой корзины и периода — метрики
    # weekly (registered) для графиков-sparklines — по неделям, 5 срезов:
    weekly_reg = defaultdict(lambda: {
        'total': defaultdict(new_reg_metrics),
        'direction': defaultdict(new_reg_metrics),
        'director': defaultdict(new_reg_metrics),
        'teamlead': defaultdict(new_reg_metrics),
        'employee': defaultdict(new_reg_metrics),
    })
    # weekly (closed) — по неделям
    weekly_closed = defaultdict(lambda: {
        'total': defaultdict(new_closed_metrics),
        'direction': defaultdict(new_closed_metrics),
        'director': defaultdict(new_closed_metrics),
        'teamlead': defaultdict(new_closed_metrics),
        'employee': defaultdict(new_closed_metrics),
    })
    # monthly — то же по месяцам
    monthly_reg = defaultdict(lambda: {
        'total': defaultdict(new_reg_metrics),
        'direction': defaultdict(new_reg_metrics),
        'director': defaultdict(new_reg_metrics),
        'teamlead': defaultdict(new_reg_metrics),
        'employee': defaultdict(new_reg_metrics),
    })
    monthly_closed = defaultdict(lambda: {
        'total': defaultdict(new_closed_metrics),
        'direction': defaultdict(new_closed_metrics),
        'director': defaultdict(new_closed_metrics),
        'teamlead': defaultdict(new_closed_metrics),
        'employee': defaultdict(new_closed_metrics),
    })
    # Cohort: close_month → reg_month → {n_connected, nd_sum, n_with_equip}
    cohort = defaultdict(lambda: defaultdict(lambda: {'n_connected': 0, 'nd_sum': 0.0, 'n_with_equip': 0}))

    # Снэпшот открытых
    open_snap = {
        'total': new_open_rec(),
        'direction': defaultdict(new_open_rec),
        'director': defaultdict(new_open_rec),
        'teamlead': defaultdict(new_open_rec),
        'employee': defaultdict(new_open_rec),
    }
    # Дневная динамика (для sparkline главной) — 2 среза: registered и closed
    daily_reg = defaultdict(lambda: {'n_total': 0})
    daily_closed = defaultdict(lambda: {'n_connected': 0, 'nd_sum': 0.0})

    weeks_meta = {}      # wkey -> (monday, sunday)
    months_meta = {}     # mkey -> (start, end)

    n_read = 0; n_our = 0; n_skip_no_date = 0
    dates_min = None; dates_max = None
    close_min = None; close_max = None

    t_iter = time.time()
    for row in rows_iter:
        n_read += 1
        if n_read % 20000 == 0:
            print(f"  ... {n_read} rows, {time.time()-t_iter:.1f}s")

        podr_prim = norm_str(row[COL['primary_podr']])
        if podr_prim not in OUR_CHANNELS:
            continue
        n_our += 1

        reg_dt = parse_dt(row[COL['reg_dt']])
        if reg_dt is None:
            n_skip_no_date += 1
            continue

        if dates_min is None or reg_dt < dates_min: dates_min = reg_dt
        if dates_max is None or reg_dt > dates_max: dates_max = reg_dt

        direction = DIR_MAP.get(podr_prim, '')
        service = norm_str(row[COL['service']]).lower()
        service_raw = norm_str(row[COL['service']]) or '—'
        current_podr = norm_str(row[COL['current_podr']])
        _stayed = current_podr in OUR_CHANNELS
        _transferred = not _stayed
        final_status = norm_str(row[COL['final_status']])
        _connected = (final_status == CONNECTED_STATUS)
        _has_final = bool(final_status)
        _in_conv_base = service not in EXCL_SERVICES
        sla_acc = norm_str(row[COL['sla_acc']]).lower()
        sla_cont = norm_str(row[COL['sla_cont']]).lower()
        _sla_acc_viol = (sla_acc == 'нарушен')
        _sla_cont_viol = (sla_cont == 'нарушен')
        equip_price = parse_num(row[COL['equip_price']])
        _with_equip = _connected and (equip_price > 0)
        # Защита от outliers: отдельные записи содержат явные ошибки ввода (НД > 1 млрд руб/мес)
        ND_OUTLIER_CAP = 1_000_000_000  # 1 млрд руб — выше этого считаем ошибкой ввода и отбрасываем
        if _connected:
            inst = parse_num(row[COL['install_amount']])
            mon_ = parse_num(row[COL['monthly_amount']])
            if inst > ND_OUTLIER_CAP: inst = 0.0
            if mon_ > ND_OUTLIER_CAP: mon_ = 0.0
            nd_val = inst + mon_
        else:
            inst = 0.0; mon_ = 0.0
            nd_val = 0.0

        # Данные для cross-sell / фрод-индикатора
        inn_val = norm_str(row[COL['inn']])
        _service_lower = service  # уже нижний регистр
        _is_internet = (_service_lower == INET_LOWER)
        # В фрод-корзину попадают только подключённые услуги, не относящиеся к EXCL_SERVICES
        _cross_eligible = _connected and _in_conv_base and bool(inn_val)

        primary_name = clean_name(row[COL['primary_name']])
        emp_info = emp_map.get(primary_name, {})
        teamlead = emp_info.get('teamlead', '')
        director = emp_info.get('director', '')

        # Периоды регистрации
        wkey_reg, mon_r, sun_r = iso_week_key(reg_dt)
        mkey_reg = month_key(reg_dt)
        if wkey_reg not in weeks_meta: weeks_meta[wkey_reg] = (mon_r, sun_r)
        if mkey_reg not in months_meta: months_meta[mkey_reg] = month_bounds(mkey_reg)

        # ------ REGISTERED агрегация ------
        def apply_reg(m):
            m['n_total'] += 1
            if _in_conv_base:
                m['n_base_all'] += 1
                if _stayed:
                    m['n_stayed_base'] += 1
                    if _connected:
                        m['n_connected_stayed_from_period'] += 1
                        m['nd_sum_from_period'] += nd_val
            if _transferred: m['n_transferred'] += 1
            if _sla_acc_viol: m['n_sla_acc_viol'] += 1
            if _sla_cont_viol: m['n_sla_cont_viol'] += 1

        for ag, key, name in [
            (weekly_reg[wkey_reg], 'total', 'all'),
            (monthly_reg[mkey_reg], 'total', 'all'),
        ]:
            apply_reg(ag[key][name])
        if direction:
            apply_reg(weekly_reg[wkey_reg]['direction'][direction])
            apply_reg(monthly_reg[mkey_reg]['direction'][direction])
        if director:
            apply_reg(weekly_reg[wkey_reg]['director'][director])
            apply_reg(monthly_reg[mkey_reg]['director'][director])
        if teamlead:
            apply_reg(weekly_reg[wkey_reg]['teamlead'][teamlead])
            apply_reg(monthly_reg[mkey_reg]['teamlead'][teamlead])
        if primary_name:
            apply_reg(weekly_reg[wkey_reg]['employee'][primary_name])
            apply_reg(monthly_reg[mkey_reg]['employee'][primary_name])

        daily_reg[reg_dt.strftime('%Y-%m-%d')]['n_total'] += 1

        # ------ CLOSED агрегация (по дате итогового статуса) ------
        if _has_final:
            final_dt = parse_dt(row[COL['final_dt']])
            if final_dt is not None:
                if close_min is None or final_dt < close_min: close_min = final_dt
                if close_max is None or final_dt > close_max: close_max = final_dt
                wkey_cl, mon_c, sun_c = iso_week_key(final_dt)
                mkey_cl = month_key(final_dt)
                if wkey_cl not in weeks_meta: weeks_meta[wkey_cl] = (mon_c, sun_c)
                if mkey_cl not in months_meta: months_meta[mkey_cl] = month_bounds(mkey_cl)

                def apply_closed(m):
                    m['n_closed'] += 1
                    if _connected:
                        m['n_connected'] += 1
                        m['by_service'][service_raw] += 1
                        if _with_equip:
                            m['n_with_equip'] += 1
                            m['by_service_equip'][service_raw] += 1
                        m['nd_sum'] += nd_val
                        # Cross-sell / фрод
                        if _cross_eligible:
                            m['inn_services'][inn_val].add(service_raw)
                            if not _is_internet:
                                m['secondaries'].append((service_raw, mon_, inn_val))

                apply_closed(weekly_closed[wkey_cl]['total']['all'])
                apply_closed(monthly_closed[mkey_cl]['total']['all'])
                if direction:
                    apply_closed(weekly_closed[wkey_cl]['direction'][direction])
                    apply_closed(monthly_closed[mkey_cl]['direction'][direction])
                if director:
                    apply_closed(weekly_closed[wkey_cl]['director'][director])
                    apply_closed(monthly_closed[mkey_cl]['director'][director])
                if teamlead:
                    apply_closed(weekly_closed[wkey_cl]['teamlead'][teamlead])
                    apply_closed(monthly_closed[mkey_cl]['teamlead'][teamlead])
                if primary_name:
                    apply_closed(weekly_closed[wkey_cl]['employee'][primary_name])
                    apply_closed(monthly_closed[mkey_cl]['employee'][primary_name])

                # Cohort — только для подключений, в разрезе месяцев
                if _connected:
                    c = cohort[mkey_cl][mkey_reg]
                    c['n_connected'] += 1
                    c['nd_sum'] += nd_val
                    if _with_equip: c['n_with_equip'] += 1

                if _connected:
                    d = daily_closed[final_dt.strftime('%Y-%m-%d')]
                    d['n_connected'] += 1
                    d['nd_sum'] += nd_val

        # ------ OPEN snapshot ------
        if not _has_final:
            hrs_in_status = parse_num(row[COL['hrs_in_status']])
            is_stale = hrs_in_status > STALE_HOURS
            def apply_open(rec):
                rec['n_open'] += 1
                rec['by_week'][wkey_reg] += 1
                if is_stale:
                    rec['n_stale30'] += 1
                    rec['stale_by_week'][wkey_reg] += 1
            apply_open(open_snap['total'])
            if direction: apply_open(open_snap['direction'][direction])
            if director: apply_open(open_snap['director'][director])
            if teamlead: apply_open(open_snap['teamlead'][teamlead])
            if primary_name: apply_open(open_snap['employee'][primary_name])

    print(f"[ETL v2] Read {n_read}, our={n_our}, skip_no_date={n_skip_no_date}, {time.time()-t0:.1f}s")
    print(f"[ETL v2] Reg dates: {dates_min} — {dates_max}")
    print(f"[ETL v2] Close dates: {close_min} — {close_max}")

    # --------- сериализация ---------

    def reg_dict(m):
        n_t = m['n_total']
        def pct(a,b): return round(100.0*a/b, 2) if b else 0.0
        return {
            'n_total': n_t,
            'n_base_all': m['n_base_all'],
            'n_stayed_base': m['n_stayed_base'],
            'n_transferred': m['n_transferred'],
            'n_sla_acc_viol': m['n_sla_acc_viol'],
            'n_sla_cont_viol': m['n_sla_cont_viol'],
            'transfer_rate': pct(m['n_transferred'], n_t),
            'sla_acc_rate': pct(m['n_sla_acc_viol'], n_t),
            'sla_cont_rate': pct(m['n_sla_cont_viol'], n_t),
            # cohort-конверсия (по периоду регистрации):
            'n_connected_stayed_from_period': m['n_connected_stayed_from_period'],
            'conv_clean': pct(m['n_connected_stayed_from_period'], m['n_base_all']),
            'conv_regular': pct(m['n_connected_stayed_from_period'], m['n_stayed_base']),
            'nd_sum_from_period': round(m['nd_sum_from_period'], 2),
        }
    def closed_dict(m):
        n_cl = m['n_closed']; n_conn = m['n_connected']
        def pct(a,b): return round(100.0*a/b, 2) if b else 0.0
        # Cross-sell
        inn_srv = m['inn_services']
        n_inn_connected = len(inn_srv)
        n_inn_multi = 0
        for s in inn_srv.values():
            if len(s) >= 2:
                n_inn_multi += 1
        # Фрод-индикатор: доля «ультра-дешёвых» вторичных (не Интернет) продуктов ≤400₽/мес
        secondaries = m['secondaries']
        n_secondary = len(secondaries)
        n_ultra_cheap = 0
        for _, price, _ in secondaries:
            if price <= ULTRA_CHEAP_RUB:
                n_ultra_cheap += 1
        return {
            'n_closed': n_cl,
            'n_connected': n_conn,
            'n_with_equip': m['n_with_equip'],
            'nd_sum': round(m['nd_sum'], 2),
            'close_conv': pct(n_conn, n_cl),      # % подключений среди всех закрытых в периоде
            'equip_share': pct(m['n_with_equip'], n_conn) if n_conn else 0.0,
            'by_service': dict(m['by_service']),
            'by_service_equip': dict(m['by_service_equip']),
            # Cross-sell
            'n_inn_connected': n_inn_connected,
            'n_inn_multi': n_inn_multi,
            'crossell_pct': pct(n_inn_multi, n_inn_connected),
            # Фрод-индикатор
            'n_secondary': n_secondary,
            'n_ultra_cheap': n_ultra_cheap,
            'fraud_pct': pct(n_ultra_cheap, n_secondary),
        }

    weeks_sorted = sorted(weeks_meta.keys())
    months_sorted = sorted(months_meta.keys())

    weeks_info = []
    for w in weeks_sorted:
        mon, sun = weeks_meta[w]
        weeks_info.append({
            'key': w,
            'start': mon.strftime('%Y-%m-%d'),
            'end': sun.strftime('%Y-%m-%d'),
            'label': f"{mon.strftime('%d.%m')}–{sun.strftime('%d.%m')}",
        })
    months_info = []
    for mk in months_sorted:
        s, e = months_meta[mk]
        months_info.append({
            'key': mk,
            'start': s.strftime('%Y-%m-%d'),
            'end': e.strftime('%Y-%m-%d'),
            'label': month_label(mk),
            'label_full': f"{month_label(mk)} {mk.split('-')[0]}",
        })

    # Определения текущего/открытого
    current_week, _, _ = iso_week_key(dates_max)
    current_month = month_key(dates_max)
    # закрытые месяцы — все где данные "полны" (т.е. все до current_month)
    closed_months = [mk for mk in months_sorted if mk < current_month]
    open_month = current_month
    # Недели в открытом месяце — все которые частично/полностью лежат в open_month
    s_om, e_om = months_meta[open_month]
    open_weeks = [w for w in weeks_sorted if weeks_meta[w][0] <= e_om and weeks_meta[w][1] >= s_om]

    # Сериализация weekly/monthly
    def serialize_per(bucket_dict, to_dict):
        out = {}
        for per, wd in bucket_dict.items():
            out[per] = {
                'total': {k: to_dict(v) for k,v in wd['total'].items()},
                'direction': {k: to_dict(v) for k,v in wd['direction'].items()},
                'director': {k: to_dict(v) for k,v in wd['director'].items()},
                'teamlead': {k: to_dict(v) for k,v in wd['teamlead'].items()},
                'employee': {k: to_dict(v) for k,v in wd['employee'].items()},
            }
        return out

    registered = {
        'by_week': serialize_per(weekly_reg, reg_dict),
        'by_month': serialize_per(monthly_reg, reg_dict),
    }
    closed = {
        'by_week': serialize_per(weekly_closed, closed_dict),
        'by_month': serialize_per(monthly_closed, closed_dict),
    }

    # Cohort: список записей {close_period, reg_period, n_connected, nd_sum, n_with_equip}
    # + агрегированная матрица only for months
    cohort_out = {
        'by_month': {cm: {rm: dict(v) for rm, v in rs.items()} for cm, rs in cohort.items()}
    }
    # Округлим nd_sum в cohort
    for cm, rs in cohort_out['by_month'].items():
        for rm, v in rs.items():
            v['nd_sum'] = round(v['nd_sum'], 2)

    # Open snapshot
    def open_to_dict(r):
        return {
            'n_open': r['n_open'],
            'n_stale30': r['n_stale30'],
            'stale_rate': round(100.0*r['n_stale30']/r['n_open'],2) if r['n_open'] else 0.0,
            'by_week': dict(r['by_week']),
            'stale_by_week': dict(r['stale_by_week']),
        }
    open_out = {
        'total': open_to_dict(open_snap['total']),
        'direction': {k:open_to_dict(v) for k,v in open_snap['direction'].items()},
        'director': {k:open_to_dict(v) for k,v in open_snap['director'].items()},
        'teamlead': {k:open_to_dict(v) for k,v in open_snap['teamlead'].items()},
        'employee': {k:open_to_dict(v) for k,v in open_snap['employee'].items()},
    }

    # Daily (для sparklines главной): объединим reg + closed в одну структуру
    all_days = sorted(set(daily_reg.keys()) | set(daily_closed.keys()))
    daily_out = {}
    for d in all_days:
        r = daily_reg.get(d, {})
        c = daily_closed.get(d, {})
        daily_out[d] = {
            'n_total': r.get('n_total', 0),
            'n_connected': c.get('n_connected', 0),
            'nd_sum': round(c.get('nd_sum', 0.0), 2),
        }

    # Сотрудники
    seen_names = set()
    for w in weeks_sorted:
        seen_names.update(weekly_reg[w]['employee'].keys())
    emp_list = []
    for name, info in emp_map.items():
        emp_list.append({
            'name': name,
            'teamlead': info['teamlead'],
            'director': info['director'],
            'direction': info['direction'],
            'mrf': info['mrf'],
            'is_active': info['is_active'],
            'in_data': name in seen_names,
        })
    for name in seen_names:
        if name and name not in emp_map:
            emp_list.append({
                'name': name, 'teamlead': '', 'director': '',
                'direction': '', 'mrf': '', 'is_active': True, 'in_data': True,
            })

    teamleads = sorted({e['teamlead'] for e in emp_list if e['teamlead']})
    directors = sorted({e['director'] for e in emp_list if e['director']})
    directions = sorted({e['direction'] for e in emp_list if e['direction']})
    mrfs = sorted({e['mrf'] for e in emp_list if e['mrf']})

    # Для главной панели строим timeline: закрытые месяцы + недели открытого
    timeline = []
    for mk in closed_months:
        s, e = months_meta[mk]
        timeline.append({
            'key': mk, 'kind': 'month',
            'label': month_label(mk),
            'label_full': f"{month_label(mk)} {mk.split('-')[0]}",
            'start': s.strftime('%Y-%m-%d'), 'end': e.strftime('%Y-%m-%d'),
            'closed': True,
        })
    for w in open_weeks:
        ws, we = weeks_meta[w]
        timeline.append({
            'key': w, 'kind': 'week',
            'label': f"{ws.strftime('%d.%m')}–{we.strftime('%d.%m')}",
            'label_full': f"{w} · {ws.strftime('%d.%m')}–{we.strftime('%d.%m')}",
            'start': ws.strftime('%Y-%m-%d'), 'end': we.strftime('%Y-%m-%d'),
            'closed': (w != current_week),
        })

    out = {
        'meta': {
            'generated_at': datetime.now().isoformat(timespec='seconds'),
            'data_from': dates_min.strftime('%Y-%m-%d %H:%M:%S') if dates_min else None,
            'data_to': dates_max.strftime('%Y-%m-%d %H:%M:%S') if dates_max else None,
            'close_from': close_min.strftime('%Y-%m-%d %H:%M:%S') if close_min else None,
            'close_to': close_max.strftime('%Y-%m-%d %H:%M:%S') if close_max else None,
            'n_rows_total': n_read,
            'n_rows_our': n_our,
            'current_week': current_week,
            'current_month': current_month,
            'closed_months': closed_months,
            'open_month': open_month,
            'open_weeks': open_weeks,
        },
        'weeks': weeks_info,
        'months': months_info,
        'timeline': timeline,
        'registered': registered,
        'closed': closed,
        'cohort': cohort_out,
        'open': open_out,
        'daily': daily_out,
        'employees': emp_list,
        'teamleads': teamleads,
        'directors': directors,
        'directions': directions,
        'mrfs': mrfs,
    }

    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(out, f, ensure_ascii=False, separators=(',',':'))
    sz = os.path.getsize(out_path)
    print(f"[ETL v2] Saved {out_path}, {sz:,} bytes, {time.time()-t0:.1f}s")
    print(f"[ETL v2] Months: {len(months_info)} (closed={len(closed_months)}, open={open_month})")
    print(f"[ETL v2] Open weeks in current month: {open_weeks}")
    print(f"[ETL v2] Teamleads={len(teamleads)} Directors={len(directors)}")


if __name__ == '__main__':
    root = '/sessions/adoring-exciting-fermi/mnt'
    muz = None; html = None
    for d in os.listdir(root):
        p = os.path.join(root, d)
        if not os.path.isdir(p): continue
        if d.startswith('.') or d in ('outputs', 'uploads'): continue
        for f in os.listdir(p):
            full = os.path.join(p, f)
            if 'МУЗ' in f and f.endswith('.xlsx') and muz is None:
                muz = full
            if f == 'dashboard_v5.html':
                html = full
    if not muz or not html:
        print(f"ERROR: muz={muz}, html={html}", file=sys.stderr)
        sys.exit(1)
    out = '/sessions/adoring-exciting-fermi/mnt/outputs/daily_data.json'
    run_etl(muz, html, out)
